(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["node-modules/uview-ui/components/u-safe-bottom/u-safe-bottom"],{"34c6":function(t,e,n){"use strict";n.r(e);var u=n("755d"),a=n("f5ce");for(var i in a)["default"].indexOf(i)<0&&function(t){n.d(e,t,(function(){return a[t]}))}(i);n("4421");var o=n("f0c5"),c=Object(o["a"])(a["default"],u["b"],u["c"],!1,null,"2dbaa680",null,!1,u["a"],void 0);e["default"]=c.exports},4421:function(t,e,n){"use strict";var u=n("d461"),a=n.n(u);a.a},"755d":function(t,e,n){"use strict";n.d(e,"b",(function(){return u})),n.d(e,"c",(function(){return a})),n.d(e,"a",(function(){}));var u=function(){var t=this.$createElement,e=(this._self._c,this.__get_style([this.style]));this.$mp.data=Object.assign({},{$root:{s0:e}})},a=[]},ccab:function(t,e,n){"use strict";(function(t){var u=n("4ea4");Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var a=u(n("22e6")),i={name:"u-safe-bottom",mixins:[t.$u.mpMixin,t.$u.mixin,a.default],data:function(){return{safeAreaBottomHeight:0,isNvue:!1}},computed:{style:function(){return t.$u.deepMerge({},t.$u.addStyle(this.customStyle))}},mounted:function(){}};e.default=i}).call(this,n("543d")["default"])},d461:function(t,e,n){},f5ce:function(t,e,n){"use strict";n.r(e);var u=n("ccab"),a=n.n(u);for(var i in u)["default"].indexOf(i)<0&&function(t){n.d(e,t,(function(){return u[t]}))}(i);e["default"]=a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'node-modules/uview-ui/components/u-safe-bottom/u-safe-bottom-create-component',
    {
        'node-modules/uview-ui/components/u-safe-bottom/u-safe-bottom-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("34c6"))
        })
    },
    [['node-modules/uview-ui/components/u-safe-bottom/u-safe-bottom-create-component']]
]);
